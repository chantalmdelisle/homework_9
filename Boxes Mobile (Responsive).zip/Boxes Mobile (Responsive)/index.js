$("button").on("click", function(){
	$("nav li").slideToggle();
});